a simple showcase site.

https://xryb1.github.io/DSA-showcase-site/
